import json,re
from pathlib import Path
r=json.load(open('parsed_rows.json'));raw=json.load(open('rawrows.json'));failures=[];printed_count=0;relay_cumulative_checks=0
for row in raw:
 c={int(k):v for k,v in row['cumulative'].items()};n=int(re.search(r'(\d+)m',row['event']).group(1))//50
 if 'Relay' in row['event']:
  offset=0;legdist=n*50
  for line in row['entry']['lines']:
   m=re.match(r'^\s{10,}([A-Za-z].*?)\s{2,}(-?\d+\.\d{2})\s+(.+)$',line)
   if not m:continue
   ss=re.sub(r'\(=?\d+\)','',m.group(3));tt=re.findall(r'(?:\d+:)?\d+\.\d{2}',ss)
   def cs(t):
    a=t.split(':');return int(round(float(a[-1])*100))+(int(a[0])*6000 if len(a)>1 else 0)
   tt=list(map(cs,tt))
   if len(tt)>n:
    offset+=tt[n-1];relay_cumulative_checks+=1
    if tt[n]!=offset:failures.append(('relay cumulative',row['book'],row['page'],row['entry']['name']))
  continue
 printed=[]
 for line in row['entry']['lines']:
  line=re.sub(r'\s+(?:Q|R|=?OR|ER|AS|AF|AM|OC|WR|WJ)(?:[, ]+[A-Z]+)*\s*$','',line)
  if re.fullmatch(r'\s*(?:(?:\d+:)?\d+\.\d{2}\s*)+',line):printed.extend(int(round(float(t)*100)) for t in line.split())
 if len(c)==n:
  if len(printed)!=n-1:failures.append(('printed split count',row['book'],row['page'],row['entry']['name']))
  else:
   expected=[c[d]-c[d-50] for d in range(100,n*50+1,50)];printed_count+=len(printed)
   if expected!=printed:failures.append(('printed split mismatch',row['book'],row['page'],row['entry']['name']))
assert not failures,failures
assert len({x['race_id'] for x in r})==len(r)
assert len({(x['competition_year'],x['event']) for x in r})==47
assert all(x['training_eligible'] for x in r if x['status']=='OK')
for x in r:
 n=x['expected_splits']
 assert n==x['distance_m']//50
 if x['training_eligible']:
  ss=[round(float(x[f'split_{d:04d}m_seconds'])*100) for d in range(50,x['distance_m']+1,50)]
  assert len(ss)==n and all(t>0 for t in ss)
  assert sum(ss)==round(float(x['finish_time_seconds'])*100)
 assert all(x[f'split_{d:04d}m_seconds']=='' for d in range(x['distance_m']+50,1501,50))
report={'entry_rows':len(r),'complete_valid_performances':sum(x['training_eligible'] for x in r),'individual_printed_duration_checks':printed_count,'relay_published_cumulative_checks':relay_cumulative_checks,'failures':failures,'event_year_combinations':47}
Path('validation.json').write_text(json.dumps(report,indent=2));print(report)
