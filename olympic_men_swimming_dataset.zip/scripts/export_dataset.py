import csv,json,hashlib,zipfile
from pathlib import Path
from collections import Counter,defaultdict
P=Path(__file__).parent;O=P/'outputs';r=json.load(open(P/'parsed_rows.json'));legs=json.load(open(P/'parsed_legs.json'))
def write(name,rows):
 rows=list(rows)
 with (O/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write('olympic_men_swimming_50m_splits_2016_2021_2024.csv',r)
lookup={(x['year'],x['event'],x['phase'],x['heat'],x['lane'],x['leg']):x for x in legs}
long=[]
for x in r:
 for d in range(50,x['distance_m']+1,50):
  y={k:v for k,v in x.items() if not k.startswith(('split_','cumulative_'))}
  leg=0;ath=x['athlete_or_team'];local=d;stroke=x['stroke'];start='block_backstroke' if stroke=='Backstroke' else 'block_dive'
  if x['event_type']=='relay':
   legdist=x['distance_m']//4;leg=(d-1)//legdist+1;local=(d-1)%legdist+1
   lg=lookup.get((x['competition_year'],x['event'],x['round'],x['race_number'],x['lane'],leg));ath=lg['name'] if lg else ''
   stroke=['Backstroke','Breaststroke','Butterfly','Freestyle'][leg-1] if x['stroke']=='Medley' else 'Freestyle'
   start='flying' if leg>1 else ('block_backstroke' if stroke=='Backstroke' else 'block_dive')
  elif stroke=='Individual Medley':stroke=['Butterfly','Backstroke','Breaststroke','Freestyle'][(d-1)//(x['distance_m']//4)]
  y.update(split_number=d//50,split_start_m=d-50,split_end_m=d,split_distance_m=50,split_time_seconds=x[f'split_{d:04d}m_seconds'],cumulative_time_seconds=x[f'cumulative_{d:04d}m_seconds'],is_last_split=int(d==x['distance_m']),split_stroke=stroke,swimmer=ath,relay_leg=leg or '',leg_split_end_m=local,leg_start_type=start)
  long.append(y)
write('olympic_men_swimming_splits_long.csv',long)
summary=[]
for key in sorted({(x['competition_year'],x['event'],x['round']) for x in r}):
 rr=[x for x in r if (x['competition_year'],x['event'],x['round'])==key]
 summary.append(dict(competition_year=key[0],event=key[1],round=key[2],entries=len(rr),races=len(set(x['race_number'] for x in rr)),valid_complete_performances=sum(x['training_eligible'] for x in rr),dns=sum(x['status']=='DNS' for x in rr),disqualified=sum(x['status']=='DSQ' for x in rr)))
write('coverage_by_event_and_round.csv',summary)
sources=[]
urls={'rio':'https://websitedevsa.blob.core.windows.net/sitefinity/docs/default-source/eventsdocuments/meet-results/international-event-results/olympic-games/2016-olympic-games.pdf','tokyo':'https://digital.la84.org/utils/getfile/collection/p17103coll8/id/87056/filename/87057.pdf','paris':'https://ltuaquatics.com/wp-content/uploads/2023/12/OG2024_SWM_B99_SWM.pdf'}
for b,y,edition in [('rio',2016,2016),('tokyo',2021,2020),('paris',2024,2024)]:
 pdf=P/('tokyo_full.pdf' if b=='tokyo' else b+'.pdf')
 sources.append(dict(competition_year=y,olympic_edition=edition,document='Official swimming results book',publisher='Rio 2016 Organising Committee' if b=='rio' else 'Tokyo Organising Committee of the Olympic and Paralympic Games' if b=='tokyo' else 'Paris 2024 Organising Committee',host='USA Swimming' if b=='rio' else 'LA84 Foundation' if b=='tokyo' else 'LTU Aquatics',download_url=urls[b],retrieved_date='2026-10-25',pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),pdf_pages=len((P/(b+'.txt')).read_text().split('\f'))-1))
write('sources.csv',sources)
report=json.load(open(P/'validation.json'));report['observed_50m_splits']=sum(bool(x['split_time_seconds']) for x in long);report['complete_valid_50m_splits']=sum(bool(x['split_time_seconds']) and x['training_eligible'] for x in long)
(O/'validation.json').write_text(json.dumps(report,indent=2))
counts=[]
for yr in [2016,2021,2024]:
 rr=[x for x in r if x['competition_year']==yr];counts.append(f"| {yr} | {len(rr)} | {sum(x['training_eligible'] for x in rr)} | {sum(x['status']=='DNS' for x in rr)} | {sum(x['status']=='DSQ' for x in rr)} |")
readme='''# Olympic men's swimming: 50 m splits

## Scope
Every men's pool event longer than 50 m at Rio 2016, Tokyo 2020 (held in 2021), and Paris 2024. Includes every entrant in the published heat, semifinal, final and conducted swim-off results. Both individual events and men's relays are included and labelled. Excludes women's events, mixed-sex relays, 50 m freestyle and open-water swimming. Men's 800 m freestyle was not contested in 2016. All pools are 50 m long.

One wide-table row represents one swimmer's performance in one round/race, or one relay team's performance. A swimmer appearing in heats, semifinals and a final has three separate records. DNS entries are retained for coverage but are not performances. No split is estimated or imputed.

| Competition year | Entry rows | Valid complete performances | DNS | DSQ |
|---|---:|---:|---:|---:|
'''+ '\n'.join(counts)+'''

## Files
- `olympic_men_swimming_50m_splits_2016_2021_2024.csv`: primary wide table.
- `olympic_men_swimming_splits_long.csv`: one row per expected 50 m interval, including blank intervals for DNS and unpublished DSQ portions. Contains interval stroke and relay swimmer/leg identifiers.
- `coverage_by_event_and_round.csv`: entry and race counts by year, event and round.
- `sources.csv`: official results-book download locations, publishers, retrieval date and SHA-256 hashes.
- `validation.json`: completed checks and counts.

## Primary CSV fields
- `race_id`: stable identifier for an entrant's year/event/round/race/lane combination, not an athlete identifier. Different lanes in the same heat have different IDs.
- `competition_year`: 2016, 2021 or 2024; `olympic_edition`: 2016, 2020 or 2024.
- `event`, `event_type`, `distance_m`, `stroke`, `sex`, `pool_length_m`: event characteristics. Relay distance is total team distance (400 or 800 m).
- `round`: Heats, Semifinals, Final, Heats Swim-Off or Semifinal Swim-Off. Cancelled/withdrawn swim-offs are not races and are excluded.
- `race_number`: heat/semifinal number. Final and swim-off use 1. `lane` is the published lane, including 0/9 where used.
- `round_rank`: placing across that round; ties retain the same rank. Blank for unranked DNS/DSQ.
- `athlete_or_team`, `noc`, `race_date`: published name/team, National Olympic Committee code, and local race date. Name spellings follow each source and may vary across Games.
- `status`: OK, DNS (did not start), or DSQ (disqualified).
- `reaction_time_seconds`: individual start reaction time when published; blank at team level. Reaction time remains included in the first official race split and is not subtracted.
- `finish_time_seconds`: official valid finish in numeric seconds; blank for DNS/DSQ.
- `expected_splits`: race distance / 50. `observed_splits`: number of available 50 m interval durations.
- `complete_splits`: 1 if all expected intervals are present, else 0. `training_eligible`: 1 only for status OK with all positive splits and a verified finish total.
- `relay_swimmers`: four relay swimmers in leg order, separated by semicolons. Empty for individual events.
- `source_url`, `source_pdf_page`, `source_event_number`: source provenance. Pages are 1-based physical PDF pages, not the page number printed on each individual report.
- `split_0050m_seconds` ... `split_1500m_seconds`: individual 50 m INTERVAL durations. For example, split_0100m_seconds is the time from 50 m to 100 m, not time since the start. A 100 m race has two populated split columns; 200 m has four; 1500 m has 30.
- `cumulative_0050m_seconds` ... `cumulative_1500m_seconds`: elapsed race times at each endpoint. Unused columns beyond an event's distance are blank.

All timing values are decimal seconds to hundredths; 1:44.72 is stored as 104.72. Missing values are empty, never zero. Individual interval durations are calculated as successive official cumulative times differenced in integer hundredths. The last interval uses the official finish. For relays, each leg's published cumulative times are offset by preceding leg totals; intervals then use the same differencing method. Published partial relay splits are retained for disqualified teams, without inventing unrecorded timings.

## Long-table additions
`split_number`, `split_start_m`, `split_end_m`, `split_distance_m`, `split_time_seconds`, `cumulative_time_seconds`, `is_last_split`, `split_stroke`, `swimmer`, `relay_leg`, `leg_split_end_m`, `leg_start_type`. All wide-table metadata is repeated. Relay leg_split_end_m is distance within that swimmer's leg. Start type describes the leg start; it does not imply each interval starts from a dive.

## Use for final-split prediction
Filter `training_eligible == 1`. For individual-race prediction also filter `event_type == "individual"`. Do not mix relays with individual swims indiscriminately: relay legs 2–4 use flying starts, and medley races change stroke. The final split is the duration at the event's full distance. Use earlier splits and available pre-finish metadata as predictors. Exclude finish time, full-distance cumulative time, final placing and qualification outcome from inputs: they reveal the outcome. Group train/test splits by swimmer (after resolving name variants), or hold out a later Games, to reduce leakage between repeated performances. This dataset is historical Olympic long-course racing; it does not cover other ability levels or short-course pools.

## Validation and coverage
47 event/year combinations. Checks include unique row IDs, expected interval counts, positive valid intervals, exact split-to-finish sums in hundredths, '''+str(report['individual_printed_duration_checks'])+''' independent comparisons with printed individual interval durations, and '''+str(report['relay_published_cumulative_checks'])+''' comparisons with published relay cumulative times. No failed checks. Every status-OK row has complete 50 m data. Three Paris continuation pages (139, 178, 196) were verified to be genuinely empty in the source book. DNS and DSQ values reflect the published result books as issued, rather than a live register of subsequent adjudications.
'''
(O/'README.md').write_text(readme)
with zipfile.ZipFile(O/'olympic_men_swimming_dataset.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in O.iterdir():
  if f.suffix!='.zip':z.write(f,f.name)
 for name in ['build_dataset.py','validate_dataset.py','export_dataset.py']:z.write(P/name,'scripts/'+name)
print(json.dumps(report));print('individual valid',sum(x['training_eligible'] and x['event_type']=='individual' for x in r));print('files',[(f.name,f.stat().st_size) for f in O.iterdir()])
