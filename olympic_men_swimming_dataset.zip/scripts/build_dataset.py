import re,csv,json,hashlib
from pathlib import Path
from decimal import Decimal
from collections import Counter,defaultdict
ROOT=Path(__file__).parent
SOURCES={'rio':'https://websitedevsa.blob.core.windows.net/sitefinity/docs/default-source/eventsdocuments/meet-results/international-event-results/olympic-games/2016-olympic-games.pdf','tokyo':'https://digital.la84.org/digital/collection/p17103coll8/id/87056/','paris':'https://ltuaquatics.com/wp-content/uploads/2023/12/OG2024_SWM_B99_SWM.pdf'}
TIME=r'-?(?:\d+:)?\d+\.\d{2}'
def cs(s):
 a=s.split(':');return int(Decimal(a[-1])*100)+(int(a[0])*6000 if len(a)>1 else 0)
def times(s):return [cs(x) for x in re.findall(TIME,s)]
def val(x):return '' if x is None else f'{x/100:.2f}'
allrows=[];legs=[];issues=[];coverage=[];rawrows=[]
for book in ['rio','tokyo','paris']:
 year={'rio':2016,'tokyo':2021,'paris':2024}[book]
 pages=(ROOT/(book+'.txt')).read_text().split('\f')
 for pn,page in enumerate(pages,1):
  em=re.search(r"Men's ((?:4 x )?\d+m (?:Freestyle(?: Relay)?|Backstroke|Breaststroke|Butterfly|Individual Medley|Medley Relay))",page[:1800])
  if not em or not re.search(r'\bResults(?: Summary)?\b',page) or 'Rank' not in page:continue
  event=em.group(1); relay='Relay' in event;dist=int(re.search(r'(\d+)m',event).group(1))*(4 if relay else 1)
  if dist==50:continue
  h=page[:page.index('Results')];phm=re.search(r'(Semifinal Swim-Off|Heats - Swim-Off|Heats Swim-Off|Heat Swim-Off|Swim-Off|Semifinals|Heats|Final)\s*(?:\n|$)',h)
  if not phm:issues.append(('phase',book,pn));continue
  phase=phm.group(1).replace(' - ',' ')
  date=re.search(r'\b(?:MON|TUE|WED|THU|FRI|SAT|SUN) (\d{1,2} [A-Z]{3} \d{4})',h)
  import datetime
  date=datetime.datetime.strptime(date.group(1),'%d %b %Y').date().isoformat() if date else ''
  eno=re.search(r'Event Number\s+(\d+)',page,re.I);eno=eno.group(1) if eno else ''
  lines=page.splitlines();start=next(i for i,l in enumerate(lines) if re.search(r'\bRank\b',l))
  data=lines[start+1:];entries=[];cur=None
  for line in data:
   if 'Legend:' in line or re.match(r'^SWM',line):break
   if relay:
    m=re.match(r'^\s*((?:=?\d+\s+){1,3})([A-Z]{3})\s*-\s*(.*?)(?:\s{2,}(.+))?$',line)
   else:
    m=re.match(r'^\s*((?:=?\d+\s+){1,3})([^\d].*?)\s{2,}([A-Z]{3})\s+(.+)$',line)
   if m:
    if cur:entries.append(cur)
    if relay:prefix,noc,name,rest=m.groups();rest=rest or '';name=noc+' - '+name
    else:prefix,name,noc,rest=m.groups()
    nums=re.findall(r'\d+',prefix);expected=3 if phase in ['Heats','Semifinals'] else 2
    rank=nums[0] if len(nums)==expected else '';heat=nums[-2] if expected==3 else '1';lane=nums[-1]
    name=re.sub(r'\s+(?:19|20)\d{2}$','',name.strip())
    cur=dict(name=name.strip(),noc=noc,rank=rank,heat=heat,lane=lane,rest=rest,lines=[],source_page=pn)
   elif cur:cur['lines'].append(line)
  if cur:entries.append(cur)
  coverage.append(dict(book=book,page=pn,event=event,phase=phase,rows=len(entries)))
  if not entries:pass # Verified genuinely empty continuation pages in Paris source
  for ent in entries:
   rest=ent['rest'];status=next((s for s in ['DSQ','DQ','DNS','DNF','DQB'] if re.search(r'\b'+s+r'\b',rest)),'OK')
   if status=='DQ':status='DSQ'
   rest=re.sub(r'^\s*\d{1,2} [A-Z]{3} \d{4}\s+','',rest)
   rest=re.sub(r'^\s*(?:19|20)\d{2}\s+','',rest)
   tt=times(re.sub(r'\(=?\d+\)','',rest));cum={};reaction=None;finish=None;members=[]
   if relay:
    finish=tt[0] if tt and status=='OK' else None
    legdistance=dist//4;legn=0;offset=0
    offset=0
    for line in ent['lines']:
     lm=re.match(r'^\s{10,}([A-Za-z][A-Za-z .\'’`-]*?)\s{2,}(-?\d+\.\d{2})(?:\s+(.*))?$',line)
     if lm:nm,rt,tail=lm.groups();tail=tail or ''
     else:
      lm=re.match(r'^\s{10,}([A-Za-z][A-Za-z .\'’`-]+?)\s*$',line)
      if not lm:continue
      nm=lm.group(1);rt='';tail=''
     lt=times(re.sub(r'\(=?\d+\)','',tail));legn+=1;members.append(nm.strip())
     lc={50*(j+1):v for j,v in enumerate(lt[:legdistance//50])}
     if offset is not None:
      for d,v in lc.items():cum[(legn-1)*legdistance+d]=offset+v
     offset=offset+lc[legdistance] if offset is not None and legdistance in lc else None
     if status=='OK' and len(lc)!=legdistance//50:issues.append(('relay leg incomplete',book,pn,ent['name'],legn,lt))
     legs.append(dict(book=book,year=year,event=event,phase=phase,heat=ent['heat'],lane=ent['lane'],team=ent['name'],leg=legn,name=nm.strip(),reaction=rt,cumulative=lc,team_status=status,source_page=pn))
    if members and len(members)!=4:issues.append(('relay members',book,pn,ent['name'],len(members)))
   else:
    if tt and abs(tt[0])<200:reaction=tt.pop(0)
    if dist<=200:
     for j,v in enumerate(tt[:dist//50]):cum[50*(j+1)]=v
     if status=='OK' and len(tt)>=dist//50:finish=tt[dist//50-1]
    else:
     if tt and status=='OK':finish=tt[0]
     for d,t in re.findall(r'(\d+)m\s*(?:\(=?\d+\)\s*)?('+TIME+')','\n'.join(ent['lines'])):cum[int(d)]=cs(t)
     if finish is not None:cum[dist]=finish
   splits={};last=0
   for d in range(50,dist+1,50):
    c=cum.get(d);p=0 if d==50 else cum.get(d-50)
    splits[d]=c-p if c is not None and p is not None else None
   complete=all(v is not None for v in splits.values());valid=complete and status=='OK' and finish is not None and sum(splits.values())==finish and all(v>0 for v in splits.values())
   if status=='OK' and not valid:issues.append(('invalid',book,pn,event,ent['name'],len(cum),dist//50,tt))
   row=dict(competition_year=year,olympic_edition=2020 if year==2021 else year,city={'rio':'Rio de Janeiro','tokyo':'Tokyo','paris':'Paris'}[book],sex='M',pool_length_m=50,event=event,event_type='relay' if relay else 'individual',distance_m=dist,stroke=event.split('m ',1)[1].replace(' Relay',''),round=phase,race_number=ent['heat'],lane=ent['lane'],round_rank=ent['rank'],athlete_or_team=ent['name'],noc=ent['noc'],race_date=date,status=status,reaction_time_seconds=val(reaction),finish_time_seconds=val(finish),expected_splits=dist//50,observed_splits=sum(v is not None for v in splits.values()),complete_splits=int(complete),training_eligible=int(valid),relay_swimmers='; '.join(members),source_url=SOURCES[book],source_pdf_page=pn,source_event_number=eno)
   key=f"{year}|{event}|{phase}|{ent['heat']}|{ent['lane']}"
   row={'race_id':hashlib.sha256(key.encode()).hexdigest()[:16],**row}
   for d in range(50,1501,50):row[f'split_{d:04d}m_seconds']=val(splits.get(d))
   for d in range(50,1501,50):row[f'cumulative_{d:04d}m_seconds']=val(cum.get(d))
   allrows.append(row);rawrows.append(dict(book=book,page=pn,event=event,phase=phase,entry=ent,cumulative=cum))
Path('parsed_rows.json').write_text(json.dumps(allrows,indent=2));Path('parsed_legs.json').write_text(json.dumps(legs,indent=2));Path('parse_issues.json').write_text(json.dumps(issues,indent=2));Path('coverage.json').write_text(json.dumps(coverage,indent=2));Path('rawrows.json').write_text(json.dumps(rawrows,indent=2))
print('Rows',len(allrows),'by year',Counter(r['competition_year'] for r in allrows),'issues',len(issues));print(json.dumps(issues[:20],indent=2))
