# Olympic men's swimming: 50 m splits

## Scope
Every men's pool event longer than 50 m at Rio 2016, Tokyo 2020 (held in 2021), and Paris 2024. Includes every entrant in the published heat, semifinal, final and conducted swim-off results. Both individual events and men's relays are included and labelled. Excludes women's events, mixed-sex relays, 50 m freestyle and open-water swimming. Men's 800 m freestyle was not contested in 2016. All pools are 50 m long.

One wide-table row represents one swimmer's performance in one round/race, or one relay team's performance. A swimmer appearing in heats, semifinals and a final has three separate records. DNS entries are retained for coverage but are not performances. No split is estimated or imputed.

| Competition year | Entry rows | Valid complete performances | DNS | DSQ |
|---|---:|---:|---:|---:|
| 2016 | 794 | 783 | 5 | 6 |
| 2021 | 861 | 845 | 6 | 10 |
| 2024 | 771 | 758 | 10 | 3 |

## Files
- `olympic_men_swimming_50m_splits_2016_2021_2024.csv`: primary wide table.
- `olympic_men_swimming_splits_long.csv`: one row per expected 50 m interval, including blank intervals for DNS and unpublished DSQ portions. Contains interval stroke and relay swimmer/leg identifiers.
- `coverage_by_event_and_round.csv`: entry and race counts by year, event and round.
- `sources.csv`: official results-book download locations, publishers, retrieval date and SHA-256 hashes.
- `validation.json`: completed checks and counts.

## Primary CSV fields
- `race_id`: stable identifier for an entrant's year/event/round/race/lane combination, not an athlete identifier. Different lanes in the same heat have different IDs.
- `competition_year`: 2016, 2021 or 2024; `olympic_edition`: 2016, 2020 or 2024.
- `event`, `event_type`, `distance_m`, `stroke`, `sex`, `pool_length_m`: event characteristics. Relay distance is total team distance (400 or 800 m).
- `round`: Heats, Semifinals, Final, Heats Swim-Off or Semifinal Swim-Off. Cancelled/withdrawn swim-offs are not races and are excluded.
- `race_number`: heat/semifinal number. Final and swim-off use 1. `lane` is the published lane, including 0/9 where used.
- `round_rank`: placing across that round; ties retain the same rank. Blank for unranked DNS/DSQ.
- `athlete_or_team`, `noc`, `race_date`: published name/team, National Olympic Committee code, and local race date. Name spellings follow each source and may vary across Games.
- `status`: OK, DNS (did not start), or DSQ (disqualified).
- `reaction_time_seconds`: individual start reaction time when published; blank at team level. Reaction time remains included in the first official race split and is not subtracted.
- `finish_time_seconds`: official valid finish in numeric seconds; blank for DNS/DSQ.
- `expected_splits`: race distance / 50. `observed_splits`: number of available 50 m interval durations.
- `complete_splits`: 1 if all expected intervals are present, else 0. `training_eligible`: 1 only for status OK with all positive splits and a verified finish total.
- `relay_swimmers`: four relay swimmers in leg order, separated by semicolons. Empty for individual events.
- `source_url`, `source_pdf_page`, `source_event_number`: source provenance. Pages are 1-based physical PDF pages, not the page number printed on each individual report.
- `split_0050m_seconds` ... `split_1500m_seconds`: individual 50 m INTERVAL durations. For example, split_0100m_seconds is the time from 50 m to 100 m, not time since the start. A 100 m race has two populated split columns; 200 m has four; 1500 m has 30.
- `cumulative_0050m_seconds` ... `cumulative_1500m_seconds`: elapsed race times at each endpoint. Unused columns beyond an event's distance are blank.

All timing values are decimal seconds to hundredths; 1:44.72 is stored as 104.72. Missing values are empty, never zero. Individual interval durations are calculated as successive official cumulative times differenced in integer hundredths. The last interval uses the official finish. For relays, each leg's published cumulative times are offset by preceding leg totals; intervals then use the same differencing method. Published partial relay splits are retained for disqualified teams, without inventing unrecorded timings.

## Long-table additions
`split_number`, `split_start_m`, `split_end_m`, `split_distance_m`, `split_time_seconds`, `cumulative_time_seconds`, `is_last_split`, `split_stroke`, `swimmer`, `relay_leg`, `leg_split_end_m`, `leg_start_type`. All wide-table metadata is repeated. Relay leg_split_end_m is distance within that swimmer's leg. Start type describes the leg start; it does not imply each interval starts from a dive.

## Use for final-split prediction
Filter `training_eligible == 1`. For individual-race prediction also filter `event_type == "individual"`. Do not mix relays with individual swims indiscriminately: relay legs 2–4 use flying starts, and medley races change stroke. The final split is the duration at the event's full distance. Use earlier splits and available pre-finish metadata as predictors. Exclude finish time, full-distance cumulative time, final placing and qualification outcome from inputs: they reveal the outcome. Group train/test splits by swimmer (after resolving name variants), or hold out a later Games, to reduce leakage between repeated performances. This dataset is historical Olympic long-course racing; it does not cover other ability levels or short-course pools.

## Validation and coverage
47 event/year combinations. Checks include unique row IDs, expected interval counts, positive valid intervals, exact split-to-finish sums in hundredths, 9835 independent comparisons with printed individual interval durations, and 849 comparisons with published relay cumulative times. No failed checks. Every status-OK row has complete 50 m data. Three Paris continuation pages (139, 178, 196) were verified to be genuinely empty in the source book. DNS and DSQ values reflect the published result books as issued, rather than a live register of subsequent adjudications.
